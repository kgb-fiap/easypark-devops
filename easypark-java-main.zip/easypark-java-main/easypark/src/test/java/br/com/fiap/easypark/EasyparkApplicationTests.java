package br.com.fiap.easypark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyparkApplicationTests {

	@Test
	void contextLoads() {
	}

}
